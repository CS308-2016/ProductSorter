Project Name: Product Sorter

Team Members:

Abhinav Gupta, 120050029
Siddharth Patel, 120050001
Dheerendra Rathor, 120050033
Anant Gupta, 120050086

Project Description:

The aim of this project is to build a setup to detect and remove bad over cooked potato chips from the good ones from the production chain. This is usually done on a conveyer belt and chips are removed using an air gun but we will use a static belt and a mechanical arm to remove the bad chips.
