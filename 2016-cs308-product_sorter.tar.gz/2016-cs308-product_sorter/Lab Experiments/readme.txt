Group A 
Name: (Roll Number)
Abhinav Gupta : 120050029
Anant Gupta : 120050086

Group B
Name: (Roll Number)
Siddharth Patel : 120050001
Dheerendra Singh Rathor : 120050033

Add a well documented and commented code of your experiments in the respective folders.
